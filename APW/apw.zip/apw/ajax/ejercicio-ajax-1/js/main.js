window.addEventListener('DOMContentLoaded', function() {
    const btnConsultar = this.document.getElementById('contenedor');

        
        const xhr = new XMLHttpRequest();
        xhr.open('GET','api/discos.json');

        xhr.addEventListener('readystatechange',() => {

            if(xhr.readyState === 4){
                if(xhr.status === 200){
                const discos= JSON.parse(xhr.response);
                console.log(discos);
                document.getElementById("discos").innerHTML = x;
                }
            }
        })
        xhr.send(null);
});