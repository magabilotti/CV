window.addEventListener('DOMContentLoaded', function() {

//registtramos nuestro SW
//paso 1: verificamos si el navegador acepta sw
if('ServiceWorker' in navegator){
    //paso 2: registramos el archivo sw.js
    navigator.serviceWorker.register('sw.js')
    .then(registration =>{
     console.log(registration);   
    })
    .catch(rejeted =>{
        console.error(rejected);
    })
}
//fin registro Service Worked


    const btnConsultar = document.getElementById('btnConsultar');
    btnConsultar.addEventListener('click',cargarDiscosFetch);

function cargarDiscosFetch(){
    let discos=[];
    let contenido = [];
    //con fetch
    fetch('api/discos.json')
    .then(response => response.json())
    .then(data =>{
        console.log('Discos: ',data);
        let contenido = [];
        discos.forEach(element => {
            let div = `
            <div class="col">
            <div class="col-3 card" id="${element.id}">
                <img src="img/${element.imagen}" class="card-img-top" alt="foto de disco">
                <div class="card-body">
                    <h5 class="card-title">${element.nombre}</h5>
                </div>
            </div>`;
            contenido.push(div);
        });
        contenedor.innerHTML = contenido;
    });
}
    
        /*
        const xhr = new XMLHttpRequest();
        xhr.open('GET','api/discos.json');

        xhr.addEventListener('readystatechange',() => {

            if(xhr.readyState === 4){
                if(xhr.status === 200){
                const discos = JSON.parse(xhr.response);
                let contenido = [];
                discos.forEach(element => {
                    let div = `
                    <div class="col">
                    <div class="col-3 card" id="${element.id}">
                        <img src="img/${element.imagen}" class="card-img-top" alt="foto de disco">
                        <div class="card-body">
                            <h5 class="card-title">${element.nombre}</h5>
                        </div>
                    </div>`;
                    contenido.push(div);
                });
                contenedor.innerHTML = contenido;
            }
        }
    })
    xhr.send(null);*/
});