//window.addEventListener('DOMContentLoaded', function() {
    const btnConsultar = document.getElementById('btnConsultar');

    
    btnConsultar.addEventListener('click',cargarDiscosFetch);

function cargarDiscosFetch(){
    let discos=[];

    //con fetch
    fetch('api/discos.json')
    .then(responde => responde.json())
    .then(data =>{
        console.log('Discos: ',date);
    })
}
    
        /*
        const xhr = new XMLHttpRequest();
        xhr.open('GET','api/discos.json');

        xhr.addEventListener('readystatechange',() => {

            if(xhr.readyState === 4){
                if(xhr.status === 200){
                const discos = JSON.parse(xhr.response);
                let contenido = [];
                discos.forEach(element => {
                    let div = `
                    <div class="col">
                    <div class="col-3 card" id="${element.id}">
                        <img src="img/${element.imagen}" class="card-img-top" alt="foto de disco">
                        <div class="card-body">
                            <h5 class="card-title">${element.nombre}</h5>
                        </div>
                    </div>`;
                    contenido.push(div);
                });
                contenedor.innerHTML = contenido;
            }
        }
    })
    xhr.send(null);*/
//});