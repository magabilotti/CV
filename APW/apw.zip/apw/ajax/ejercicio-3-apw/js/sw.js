//intalación 
self.addEventListener('install',(e) =>{
    //saltamos la espera de forma automatica
    self.skipwaiting();
    console.log('Service Worker Instalado',e);
})

//activación
self.addEventListener('activate',(e) =>{
    console.log('service Worker Activo',e);
})

//capturamos las peticiones de la interfaz
self.addEventListener('fetch',(e)=>{

})

//hasta la diapo 26