window.addEventListener('DOMContentLoaded', function() {

//registtramos nuestro SW
//paso 1: verificamos si el navegador acepta sw
if('ServiceWorker' in navigator){
    //paso 2: registramos el archivo sw.js
    navigator.serviceWorker.register('sw.js')
    .then(registration =>{
     console.log(registration);   
    })
    .catch(rejeted =>{
        console.error(rejected);
    })
}
//fin registro Service Worked

    //con fetch
    fetch('api/discos.json')
    .then(response => response.json())
    .then(data => {
      console.log('Discos: ',data);
      let contenido = [];
      data.forEach(element => {
          let div = `
          <div class="col">
          <div class="col-3 card" id="${element.id}">
              <img src="img/${element.imagen}" class="card-img-top" alt="foto de disco">
              <div class="card-body">
                  <h5 class="card-title">${element.nombre}</h5>
              </div>
          </div>`;
          contenido.push(div);
      });
      contenido.innerHTML = contenido;
  });
});
/*
    fetch('api/discos.json')
    .then(response => response.json())
    .then(data => {
      console.log('Discos: ',data);
        Object.values(data).forEach((item => {
            let cards = document.getElementById('cards')
            let divCard = document.createElement('div')
                divCard.classList.add('card')
            let imagen = document.createElement('img')
                imagen.setAttribute('src','img/' + item.imagen)
                imagen.classList.add('card-img-top')
            let cardBody = document.createElement('div')
                cardBody.classList.add('card-body')
            let nombre = document.createElement('p')
                nombre.textContent = item.nombre
                nombre.classList.add('card-title')
            let id = document.createElement('p')
                id = textContent = item.id
                id.classList.add('card-text')

            cards.appendChild(divCard);
            divCard.appendChild(imagen);
            divCard.appendChild(cardBody);
            cardBody.appendChild(nombre);
            cardBody.appendChild(id);

        }));
    });
});*/

      /*
          const btnConsultar = document.getElementById('btnConsultar');
    btnConsultar.addEventListener('click',cargarDiscosFetch);

function cargarDiscosFetch(){
    let discos=[];
    let contenido = [];
    //con fetch
    fetch('api/discos.json')
    .then(response => response.json())
    .then(data =>{
      console.log('Discos: ',data);
        let contenido = [];
        discos.forEach(element => {
            let div = `
            <div class="col">
            <div class="col-3 card" id="${element.id}">
                <img src="img/${element.imagen}" class="card-img-top" alt="foto de disco">
                <div class="card-body">
                    <h5 class="card-title">${element.nombre}</h5>
                </div>
            </div>`;
            contenido.push(div);
        });
        contenido.innerHTML = contenido;
    });
}
});*/