const btnGenerar = document.getElementById('btnGenerar');

/*btnGenerar.addEventListener('click',cargarPaginaVuelos);*/

btnGenerar.addEventListener('click',cargarPaginaVuelosFetch);
/*
let vuelosCompletos = false,
    destinosCompletos = false,
    vuelos = [],
    destinos = [];

function cargarPaginaVuelos() {
    
    agregarLoader();

    // ejecutamos el ajax para traer los vuelos 
    const xhrVuelos=new XMLHttpRequest();
    xhrVuelos.open('GET', 'api/data-vuelos.json');
    xhrVuelos.addEventListener('readystatechange',()=>{
        if (xhrVuelos.readyState ===4){
            if(xhrVuelos.status===200){
                vuelos = JSON.parse(xhrVuelos.responseText); 
                vuelosCompletos = true;

                if(destinosCompletos) {
                    quitarLoader();
                    generarInterfaz();
                }
            }
        }
    });
xhrVuelos.send(null);
    // ejecutamos el ajax para traer los destinos
    const xhrDestinos=new XMLHttpRequest();
    xhrDestinos.open('GET', 'api/data-destinos.json');
    xhrDestinos.addEventListener('readystatechange',()=>{
        if (xhrDestinos.readyState ===4){
            if(xhrDestinos.status===200){
                destinos = JSON.parse(xhrDestinos.responseText); 
                destinosCompletos = true;

                if(destinosCompletos) {
                    quitarLoader();
                    generarInterfaz();
                }
            }
        }
    });
xhrDestinos.send(null);
}


function agregarLoader(){
    console.log('Agregamos el Loader');
}
function quitarLoader(){
    console.log('Quitamos el Loader');
}

function generarInterfaz(){
    console.log('Generamos la intefaz');
    console.log(vuelos);
    console.log(destinos);
}
*/
function cargarPaginaVuelosFetch() {
    let vuelos = [],
    destinos = [];

    //con fetch
    fetch('api/data-destinos.json')
    .then(response => response.json())
    .then(data =>{
        console.log('Vuelos: ',data);
        fetch('api/data-destinos.json')
        .then(response => response.json())
        .then(data =>{
            console.log('Destinos: ',data);
        console.log('Tenemso Vuelos y Destinos');
        });
    });
}
    /*agregarLoader();
    Promise.all([
        ajaxRequest({url: 'api/vuelos'}),
        ajaxRequest({url: 'api/destinos'})
    ]).then(respuestas => {
        vuelos = respuestas[0];
        destinos = respuestas[1];
        quitarLoader();
        generarInterfaz();
    })  
}


function cargarPaginaVuelos() {
    let vuelos = [],
    destinos = [];
    agregarLoader();
        Promise.all([
        ajaxRequest({url: 'api/vuelos'}),
        ajaxRequest({url: 'api/destinos'})
    ]).then(respuestas => {
        vuelos = respuestas[0];
        destinos = respuestas[1];
        quitarLoader();
        generarInterfaz();
    })
}*/
