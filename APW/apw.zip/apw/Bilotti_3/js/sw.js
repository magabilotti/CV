// declaro varibales para el nombre del chache yarray con recursos para almacenar pre-cache
const cacheName = 'pwa-cache-files';
const assets = ['index.html', 
                'css/main.css', 
                'js/main.js',
                'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css',
                'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js'] 

//intalación 
self.addEventListener('install',(e) => {
    //saltamos la espera de forma automatica
    self.skipwaiting();
    console.log('Service Worker Instalado',e);
    
    //hacemos el pre caching, guardar en cache los recursos para carga inicial del index
    e.waitUntil(
        //cache.open > si existe, lo abre y no lo crea
        caches.open(cacheName)
            .then(cache =>{
                cache.addAll(assets);
            })
    );
})

//activación
self.addEventListener('activate',(e) => {
    console.log('service Worker Activo',e);
})

//capturamos las peticiones de la interfaz
self.addEventListener('fetch',(e) => {
    console.log('Request',e);
    e.responseWhith(
        caches.match(e.request)// buscamos el recurso si esta en el cache del SW
        .then(response =>{
            if(response){ // si esta y tiene contenido
                return response; //devuelvo el recurso
            }
            return fetch(e.request);//si no se fue por el retorno de arriba,fetch al servidor
        })
    )
})
